
# Blog de Livros - Estrutura AOP2
Projeto de exemplo para AOP2 — tema: Livros.

Páginas: index.html, resenhas.html, lancamentos.html, autores.html, contatos.html.

Instruções rápidas para publicar no GitHub Pages:
1. Crie um repositório no GitHub (ex.: nome `aop2-blog-livros`).
2. Faça upload dos arquivos do diretório raiz (index.html, styles.css, imagens e páginas).
3. Nas configurações do repositório vá em "Pages" -> selecione a branch `main` e pasta `/ (root)` e salve.
4. Em alguns minutos seu site estará disponível em https://SEU_USUARIO.github.io/SEU_REPOSITORIO (substitua conforme).

Substitua os textos e imagens por conteúdo real antes de submeter como trabalho.
